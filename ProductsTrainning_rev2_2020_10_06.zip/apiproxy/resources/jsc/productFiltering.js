 var response=context.getVariable("message.content");
 response=JSON.parse(response);
 
 var filters= context.getVariable("momra.ev.request.uri.filter"); //"name,image"
 print(filters)
filters=filters.split(",");
 
 var productItem={}
for (i=0;i<filters.length;i++) {
    filter=filters[i];
    if(filter==="name"){
        productItem.name=response.product_name
    } else if(filter === "image"){
        productItem.images=response.images
    }
}

context.setVariable("response.content",JSON.stringify(productItem));