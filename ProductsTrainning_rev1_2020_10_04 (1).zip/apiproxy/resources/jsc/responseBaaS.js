
try{
    // print(context.getVariable("private.sfda.kvm.firestore.credentials.username"),context.getVariable("private.sfda.kvm.firestore.credentials.password"))
    
    var payload = context.getVariable('response.content');
    var targetResponsePayload = JSON.parse(payload);
    var pathSuffix = context.getVariable('pathSuffix');
    var baasPayload = {};
    
    var page=context.getVariable('momra.ev.request.pagination.page');
    var size=context.getVariable('momra.ev.request.pagination.size'); 
    //var isPagination=context.getVariable('sfda.request.pagination.enabled');
    if (page === null && size === null){
        //Default Variables
        var page= 1;
        var size= 5;
    }
    
    
    baasPayload.data = [];
    regex = /\/(products|stores|skus)\/\w*/;
    //storesRegex = /(\/*\/)/;
    if(regex.test(pathSuffix)){
        print("regex");
        baasPayload.data.push(targetResponsePayload);
    } else {
        for (var key in targetResponsePayload) {
            if (targetResponsePayload.hasOwnProperty(key)) {
                baasPayload.data.push(targetResponsePayload[key]);
            }
        }
    }
    

    response=paginate(baasPayload.data,size,page);
    context.setVariable('response.content', JSON.stringify(response.data));
    context.setVariable('momra.js.response.pagination.hasMore',response.hasMore);
    
    context.setVariable('momra.js.response.pagination.page', parseInt(page).toFixed(0));
    context.setVariable('momra.js.response.pagination.size', parseInt(size).toFixed(0));
    
}catch(e){
    context.setVariable("momra.js.JS-ResponseBaaS.isError",true);
    print("momra.custome.errors: ",e);
}

function paginate(array, page_size, page_number) {
    var startIndex=(page_number - 1) * page_size;
    var endIndex=page_number * page_size;
    var hasMore=false;
    
    if (endIndex < array.length-1){
        hasMore=true;
    }else{
        hasMore=false;
    }
    
    return {'data': array.slice(startIndex,endIndex), 'hasMore': hasMore};
}