

 print(context.getVariable("sfda.response.product.item"))