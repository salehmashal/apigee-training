 var productId=context.getVariable("momra.ev.request.uri.id");
 var path="/db/products/"+productId+".json";
 
 context.setVariable("momra.js.request.uri.id",path);
 print(path);
 