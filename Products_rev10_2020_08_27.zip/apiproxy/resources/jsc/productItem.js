try{
     var response=JSON.parse(context.getVariable("message.content"));
     var productID=context.getVariable("sfda.request.uri.id");
     
     var wantedItem=response[productID];
    
     context.setVariable("response.content",JSON.stringify(wantedItem))
     print(JSON.stringify(wantedItem)); 
}catch(e){
    context.setVariable("sfda.js.formatingLikeBaaS.isError",true);
    print("sfda.custome.errors: ",e);
}